package model;

public class LanchePedido {
    private String nomelanche;
    private int idpedido;
    private String observacao;
    private int quantidade;

    public String getNomelanche() {
        return nomelanche;
    }

    public void setNomelanche(String nomelanche) {
        this.nomelanche = nomelanche;
    }

    public int getIdpedido() {
        return idpedido;
    }

    public void setIdpedido(int idpedido) {
        this.idpedido = idpedido;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    
    
    
}
