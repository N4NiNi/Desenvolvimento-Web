package model;

public class Lanche {
    private String nomelanche;
    private float valor;

    public String getNomelanche() {
        return nomelanche;
    }

    public void setNomelanche(String nomelanche) {
        this.nomelanche = nomelanche;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }
}
